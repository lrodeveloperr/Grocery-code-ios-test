# Google Play Listing — United States and Puerto Rico

**App:** SNAP-EBT & WIC Benefits Tracker  
**Developer profile:** Good Use Studios  
**Legal operator:** Lateef Razaq-Oyetola  
**Category:** Shopping

## Short description

Plan benefit-card groceries privately and avoid checkout surprises.

## Full description

Plan before checkout with a private, manual grocery-benefit tracker designed to reduce balance surprises and awkward split payments.

Choose SNAP/EBT for the states and Washington, D.C., or Puerto Rico's Programa de Asistencia Nutricional (PAN; NAP in English). Add locally named SNAP/PAN and WIC card records and a cash shopping budget without entering card numbers or PINs. Record the balances and benefits you checked and build carts with quantities and known or not-yet-known prices.

Search and correct locally recorded purchase history, use your own eligible / not eligible / not sure labels, and create filterable reports with Overview, Benefits, Spending, and Trends views. Share CSV, Excel-compatible XLSX, and U.S.-Letter PDF files, or export and import an encrypted or unencrypted History-only backup. Tracker records remain in app-private local storage. Core tracking and report generation work without internet.

Features:

- Multiple local SNAP/PAN and WIC records without card numbers or PINs
- Cash shopping budgets with configurable periods
- Exact-cent tracked balances and controlled corrections
- English and Puerto Rican Spanish
- Puerto Rico program and Tarjeta de la Familia wording
- Searchable purchase and item history
- Reuse saved baskets, correct local transactions, and delete imported History records
- CSV, Excel-compatible XLSX, and U.S.-Letter PDF reports generated on the device
- Encrypted or unencrypted History JSON transfer
- Transactional local storage and rolling recovery snapshots
- No App account, Publisher database, or Publisher cloud backup

The App is free and may show one non-personalized AdMob banner in a dedicated area on eligible screens. It has no subscriptions, in-app purchases, interstitial ads, rewarded ads, or inline/native ads. The banner is not shown on Cards & Budgets and never unlocks or blocks reports or exports.

SNAP-EBT & WIC Benefits Tracker is an independent manual planning tool. It is not affiliated with, endorsed by, authorized by, sponsored by, or operated by USDA, FNA, the Puerto Rico Department of the Family or ADSEF, any government agency, EBT or WIC processor, or retailer. It does not connect to a benefit account, add or transfer benefits, show an official balance, determine official eligibility, or process grocery or benefit payments. Official program and retailer records control.

Never enter an EBT card number, Family Card number, PIN, Social Security number, or government-account credential.

Support: lrodeveloperr@gmail.com  
Privacy: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html  
Terms: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/terms.html

## Español (Puerto Rico)

**Descripción corta:** Planifica tus compras con beneficios en privado y evita sorpresas al pagar.

Planifica antes de pagar con un registro manual y privado. Escoge SNAP/EBT o el Programa de Asistencia Nutricional (PAN), registra tarjetas locales de PAN y WIC y un presupuesto de compra sin escribir números de tarjeta ni PIN, anota los balances que consultaste y crea carritos con cantidades y precios conocidos o pendientes.

Busca y corrige el historial, usa tus propias clasificaciones y crea reportes filtrables de Resumen, Beneficios, Gastos y Tendencias. Comparte archivos CSV, XLSX compatibles con Excel y PDF tamaño Carta, o exporta e importa una copia del Historial cifrada o sin cifrar. Los datos permanecen en almacenamiento local privado y las funciones principales trabajan sin internet.

La Aplicación es gratis y puede mostrar un solo banner no personalizado de AdMob en un área separada de las pantallas compatibles. No ofrece suscripciones ni compras dentro de la aplicación y no usa anuncios intersticiales, recompensados, integrados ni nativos. El banner no aparece en Tarjetas y presupuestos ni condiciona informes o exportaciones.

La Aplicación es independiente. No está afiliada, respaldada, autorizada, patrocinada ni operada por USDA, FNA, el Departamento de la Familia o ADSEF, ninguna agencia, ningún procesador EBT ni ningún comercio. No se conecta a cuentas, añade beneficios, muestra balances oficiales, decide elegibilidad ni procesa compras de supermercado o pagos de beneficios.
