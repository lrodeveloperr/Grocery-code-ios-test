---
title: Terms and Conditions — SNAP-EBT & WIC Benefits Tracker
description: Terms and Conditions for SNAP-EBT & WIC Benefits Tracker on Android and iOS
---

# SNAP-EBT & WIC Benefits Tracker Terms and Conditions

**Effective date:** August 10, 2026  
**Last updated:** August 10, 2026  
**Applies to:** Version 1.0.0 on Android and iOS

These Terms and Conditions (**Terms**) govern your use of SNAP-EBT & WIC Benefits Tracker (the **App**). The App is provided by **Lateef Razaq-Oyetola**, an individual developer in Ontario, Canada (**Publisher**, **we**, **us**, or **our**). The Google Play listing may display the developer-profile name **Good Use Studios**; that profile name is not a separate legal entity. The Apple App Store seller is **Lateef Razaq-Oyetola**.

A substantively equivalent Puerto Rican Spanish version appears [below](#términos-y-condiciones--español-puerto-rico).

## 1. Agreement

By downloading, accessing, or using the App, you agree to these Terms and acknowledge the [Privacy Policy](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html). If you do not agree, do not use the App.

These Terms supplement the rules of the store from which you obtained the App. For an iOS download, Apple's [Standard Licensed Application End User License Agreement](https://www.apple.com/legal/internet-services/itunes/dev/stdeula/) (**Apple Standard EULA**) also applies. If these Terms conflict with a mandatory store term or a non-waivable law, the mandatory term or law controls to the extent of the conflict.

## 2. Adults only and market

You must be **18 years or older** and legally able to agree to these Terms. The App is intended for adults in the 50 U.S. states, Washington, D.C., and Puerto Rico. Do not use the App where its use would violate applicable law.

The App is not directed to children and must not be used as a child-directed service.

## 3. Limited license

Subject to these Terms and applicable store rules, the Publisher grants you a personal, limited, revocable, non-exclusive, non-transferable license to install and use the App on a device you own or control for lawful household grocery-benefit planning.

You may not sell, sublicense, distribute, reverse engineer, tamper with, misuse, interfere with, or attempt unauthorized access to the App or its services, except to the extent applicable law expressly permits an activity that cannot be restricted by contract.

## 4. What the App does

The App is a manual, device-local grocery-benefit tracker. It lets you:

- choose English or Puerto Rican Spanish independently from the benefit program;
- choose **SNAP/EBT — States and D.C.** or **Nutrition Assistance Program (NAP; PAN in Spanish) — Puerto Rico**;
- create locally named SNAP/PAN and WIC records and tracked balances;
- record manual balance and WIC-benefit changes;
- set and monitor a cash shopping budget with configurable periods;
- build carts with item names, prices, quantities, and your own classifications;
- save, copy, search, filter, and correct locally recorded purchase records;
- delete saved baskets and imported History records;
- remember a classification for a matching item name while keeping historical tracked-balance adjustments controlled;
- use filterable Overview, Benefits, Spending, and Trends reports and generate CSV, Excel-compatible XLSX, and U.S.-Letter PDF exports on the device; and
- export or import an encrypted or unencrypted History-only JSON backup.

The App has no account, login, Publisher-operated database, Publisher-operated cloud backup, subscription, or in-app purchase. Its core tracking functions and reports work without internet. Internet access is used for advertising privacy messaging, the banner ad, external links, and destinations you choose when sharing.

## 5. Independent manual tracker—not an official service

SNAP, EBT, PAN, NAP, and WIC are used descriptively. The App is **not affiliated with, endorsed by, authorized by, sponsored by, or operated by the U.S. Department of Agriculture (USDA), the USDA Food and Nutrition Administration (FNA, formerly FNS), the Puerto Rico Department of the Family or ADSEF, any state, territorial, or tribal agency, any EBT or WIC processor, any retailer, Apple, or Google**.

The App does not:

- connect to an EBT, NAP/PAN, WIC, or government benefit account;
- load, receive, issue, transfer, or process benefits;
- display or verify an official balance or transaction history;
- determine SNAP, PAN, NAP, WIC, household, or item eligibility;
- submit a grocery purchase or process a grocery or benefit payment; or
- guarantee how a retailer, terminal, agency, or benefit program will treat an item or transaction.

Official program rules, your official account, retailer systems, receipts, and applicable law control. Confirm important balances, transactions, eligible items, and program rules with an official source.

## 6. Your entries, classifications, and tracked balances

The App's results depend on information you enter and choices you make. **Tracked balance** means only the figure recorded locally in the App. Recording a manual balance or benefit change affects only that local figure; it does not add benefits to a real card.

**Marked eligible**, **marked not eligible**, and **not sure** are your personal planning classifications. They are not legal advice, an agency determination, or a retailer guarantee. A remembered classification for a matching name is a convenience only; you remain responsible for reviewing it.

Price, quantity, purchase, funding, and transaction-detail corrections may adjust a tracked balance as shown. A historical classification change may affect reports and future defaults without changing a real account or automatically rewriting a historical tracked charge. Review every entry and correction before relying on it.

## 7. Your responsibilities

You agree to:

- enter information lawfully and review it for accuracy;
- use official sources whenever an exact benefit balance or eligibility decision matters;
- protect your device with reasonable security;
- review copied prices and classifications before saving a copied cart;
- review reports before sharing them; and
- delete exported files from every destination where you no longer want them stored.

**Never enter or send an EBT, Family Card, or WIC card number; PIN; Social Security number; government-account credential; or other authentication secret.** The App does not need them. Support will never ask for your PIN.

You retain your rights in information you enter. Because the Publisher does not receive your locally stored entries, you grant no license to the Publisher over them. If you voluntarily send information to support, you permit its limited use to answer the request, protect the App and users, and meet legal obligations as described in the Privacy Policy.

## 8. Advertising

The App is supported by Google Mobile Ads. It requests non-personalized ads and may display only one banner at a time in a dedicated area on eligible screens. It does not use interstitial, rewarded, inline, or native ad formats.

The banner is not displayed on **Cards & Budgets** and is temporarily hidden while a modal, money-entry keypad, checkout commit, report export, or print flow is active. Advertising never unlocks, restricts, or delays a feature, report, or export. If consent does not permit an ad request, no ad is available, or the device is offline, the App remains usable and no ad layer covers an input or navigation control.

The App currently offers no subscription, consumable or non-consumable in-app purchase, or paid ad-free entitlement. Google and participating ad sources control available banner creative and availability. Use **Settings → Report an Ad** or the ad's own information/report control to report inappropriate or age-inappropriate advertising. Advertising privacy choices are available in Settings when required. See the [Privacy Policy](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) and [Support page](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html).

## 9. Local storage, exports, and possible data loss

Tracker records are stored in the App's private local container. Android app-data backup is disabled, and App-created tracker files on iOS are configured not to be included in iCloud or device-cloud backup. The App uses local transactional storage and recovery data, but it cannot guarantee recovery after uninstalling, clearing storage, device loss, hardware failure, or operating-system action.

CSV, Excel-compatible XLSX, and PDF reports are generated on the device and may contain private household-shopping information. Report exports are not restorable App backups. The separately labelled History backup is an importable JSON file containing transaction history only; it does not contain or restore current card balances, WIC availability, or the shopping budget. It may be exported unencrypted or encrypted with a passphrase. The Publisher does not receive the file or passphrase and cannot recover a forgotten passphrase.

When you save or share a report or History backup, the selected destination controls that copy. The Publisher cannot retrieve or delete it for you. Temporary App-created share files are deleted after the share attempt, or on the next launch if immediate cleanup is interrupted.

Use **Settings → Clear All Data** to permanently reset local cards, balances, WIC benefits, shopping budgets, transactions, corrections, drafts, saved baskets, imported-history records and batches, report selections, learned suggestions, settings, and local recovery data, then return to onboarding. This does not delete files already exported or shared, third-party advertising-consent records, or information held independently by Apple, Google, email providers, or sharing destinations.

## 10. No professional or official advice

The App is a manual household-planning aid. It is not financial, legal, tax, nutritional, social-service, benefits, or other professional advice. Reports are based only on saved entries and are not official statements, receipts, eligibility decisions, or evidence that an agency or retailer must accept.

For an official balance, transaction, eligible-food rule, lost card, suspected fraud, denied purchase, or benefit decision, contact the applicable official agency, benefit-card customer-service channel, retailer, or USDA resource.

## 11. Privacy

The [Privacy Policy](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) explains local storage, Google Mobile Ads and UMP data, support communications, exports, retention, deletion, adults-only positioning, cross-border processing, and privacy choices. By using the App, you acknowledge those practices. Consent or privacy choices for advertising are handled through the applicable privacy flow where required.

## 12. Third-party services

The App depends in part on third-party software and services, including Apple or Google distribution, Google Mobile Ads and UMP, operating-system file and sharing functions, email, and destinations you select. Their terms and policies apply to their services. The Publisher does not control their availability, ad content, official benefit systems, retailer systems, or your selected export destinations.

The Publisher—not Apple, Google, USDA, a government agency, benefit processor, or retailer—is responsible for the App and its support, except where a store's terms state otherwise. Apple and Google have no obligation to provide maintenance or support for the App beyond their own applicable obligations.

See [Third-Party Notices](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/third-party-notices.html).

## 13. Ownership and trademarks

The Publisher and licensors own the App's original software, design, text, graphics, and other protected material, excluding your entries and third-party material. These Terms do not transfer ownership to you. Open-source software remains governed by its applicable licenses.

Third-party names and marks, including SNAP, EBT, PAN, NAP, USDA, Apple, Google, and Excel, are used descriptively and remain the property of their respective owners, where applicable. Descriptive reference does not imply endorsement.

## 14. Availability, updates, and changes

We aim to keep the App useful, secure, and compatible, but do not promise uninterrupted availability, ad availability, compatibility with every device or sharing destination, permanent availability of every feature, or acceptance of every report by third-party software.

We may release updates to correct errors, improve security or accessibility, maintain compatibility, respond to law or store policy, or change features. Store acceptance and continued listing are controlled by Apple and Google.

## 15. Disclaimer of warranties

To the maximum extent permitted by applicable law, the App is provided **“as is” and “as available.”** The Publisher disclaims implied warranties of merchantability, fitness for a particular purpose, non-infringement, accuracy, and uninterrupted or error-free operation.

This clause does not exclude any warranty, condition, right, or remedy that applicable consumer law does not permit us to exclude.

## 16. Limitation of liability

To the maximum extent permitted by applicable law, the Publisher will not be liable for indirect, incidental, special, consequential, exemplary, or punitive damages, or for lost data, lost benefits, denied transactions, checkout delays, embarrassment, device loss, lost opportunities, or reliance on inaccurate entries, classifications, tracked balances, reports, third-party ads, retailer decisions, program changes, or unavailable services.

Where liability cannot legally be excluded, it is limited only to the extent permitted by applicable law. Nothing in these Terms limits liability for fraud, willful misconduct, gross negligence, personal injury caused by negligence, or any consumer right or remedy that cannot legally be limited.

## 17. Ending use or distribution

You may stop using the App at any time and may use **Settings → Clear All Data** before uninstalling. We may suspend support or distribution if reasonably necessary for security, abuse prevention, law, third-party requirements, or store policy. Ending distribution does not give the Publisher access to data on your device.

Sections that by their nature should survive—including ownership, disclaimers, liability limits, governing law, and dispute terms—continue after use ends.

## 18. Governing law and disputes

These Terms are governed by the laws of Ontario and the applicable federal laws of Canada, without regard to conflict-of-law rules. This choice does **not** deprive a U.S. consumer of mandatory federal, state, territorial, or local protections that apply to that consumer.

Before filing a claim, you and the Publisher are encouraged to try to resolve it by emailing `lrodeveloperr@gmail.com`. This informal step does not shorten or waive a legal deadline. Ontario courts have non-exclusive jurisdiction, subject to any right to bring a claim in another competent forum under mandatory law.

These Terms do not require arbitration and do not waive participation in a class action where such a waiver would be invalid or unavailable.

## 19. General terms

If a provision is unenforceable, it will be limited or removed only to the minimum extent necessary, and the rest will continue. Failure to enforce a provision is not a waiver. You may not assign these Terms without consent. The Publisher may assign them as part of a lawful transfer of the App or related business, subject to applicable privacy and consumer law.

## 20. Changes to these Terms

We may update these Terms for changes in the App, advertising, law, or store requirements. New Terms will show a new effective date. Material changes will be highlighted in the App, release notes, or store listing when reasonably practicable. Renewed agreement will be requested when required by law; otherwise, continued use after the effective date means you accept the updated Terms.

## 21. Contact

**Publisher:** Lateef Razaq-Oyetola  
**Location:** Ontario, Canada  
**Email:** `lrodeveloperr@gmail.com`  
**Support:** [SNAP-EBT & WIC Benefits Tracker Support](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html)

---

# Términos y condiciones — Español (Puerto Rico)

**Fecha de vigencia:** 10 de agosto de 2026  
**Última actualización:** 10 de agosto de 2026  
**Aplica a:** Versión 1.0.0 en Android y iOS

Estos Términos y condiciones (**Términos**) rigen el uso de SNAP-EBT & WIC Benefits Tracker (la **Aplicación**). La Aplicación es ofrecida por **Lateef Razaq-Oyetola**, desarrollador individual en Ontario, Canadá (el **Proveedor**, **nosotros** o **nuestro**). La ficha de Google Play puede mostrar el nombre de perfil **Good Use Studios**; ese perfil no es una entidad legal separada. El vendedor en Apple App Store es **Lateef Razaq-Oyetola**.

## 1. Aceptación

Al descargar, acceder o usar la Aplicación, aceptas estos Términos y reconoces la [Política de privacidad](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html). Si no aceptas, no uses la Aplicación.

Estos Términos complementan las reglas de la tienda. Para iOS también aplica la [Licencia estándar de aplicaciones de Apple](https://www.apple.com/legal/internet-services/itunes/dev/stdeula/). Si hay conflicto con una regla obligatoria de la tienda o una disposición legal irrenunciable, esa regla o ley controla en la medida del conflicto.

## 2. Solo para personas adultas y mercado

Debes tener **18 años o más** y capacidad legal para aceptar. La Aplicación está destinada a personas adultas en los 50 estados, Washington D.C. y Puerto Rico. No la uses donde hacerlo viole la ley.

No está dirigida a menores ni debe usarse como servicio para niños.

## 3. Licencia limitada

Sujeto a estos Términos y las reglas de la tienda, el Proveedor concede una licencia personal, limitada, revocable, no exclusiva e intransferible para instalar y usar la Aplicación en un dispositivo que poseas o controles para la planificación lícita de compras del hogar con beneficios de asistencia alimentaria.

No puedes vender, sublicenciar, distribuir, hacer ingeniería inversa, alterar, usar indebidamente, interferir ni intentar acceso no autorizado, salvo cuando una ley permita expresamente una actividad que no pueda restringirse por contrato.

## 4. Qué hace la Aplicación

Es un registro manual y local de beneficios para compras. Permite:

- escoger inglés o español de Puerto Rico independientemente del programa;
- escoger **SNAP/EBT — Estados y D.C.** o **Programa de Asistencia Nutricional (PAN; NAP, por sus siglas en inglés) — Puerto Rico**;
- crear registros locales de SNAP/PAN y WIC y balances registrados;
- registrar cambios manuales de balances y beneficios WIC;
- establecer y vigilar un presupuesto de compra con períodos configurables;
- crear carritos con nombres, precios, cantidades y tus clasificaciones;
- guardar, copiar, buscar, filtrar y corregir compras registradas localmente;
- borrar listas guardadas y registros importados del Historial;
- recordar una clasificación para un artículo con el mismo nombre manteniendo controlados los ajustes históricos;
- usar reportes filtrables de Resumen, Beneficios, Gastos y Tendencias y generar archivos CSV, XLSX compatibles con Excel y PDF tamaño Carta de EE. UU. en el dispositivo; y
- exportar o importar una copia JSON del Historial cifrada o sin cifrar.

No hay cuenta de la Aplicación, inicio de sesión, base de datos del Proveedor, copia en la nube del Proveedor, suscripción ni compra dentro de la aplicación. Las funciones principales y los informes trabajan sin internet. Internet se usa para mensajes de privacidad publicitaria, el banner, enlaces externos y destinos que eliges al compartir.

## 5. Registro manual independiente, no servicio oficial

SNAP, EBT, PAN, NAP y WIC se mencionan únicamente con fines descriptivos. La Aplicación **no está afiliada, respaldada, autorizada, patrocinada ni operada por USDA, la Food and Nutrition Administration (FNA, antes FNS), el Departamento de la Familia de Puerto Rico o ADSEF, ninguna agencia estatal, territorial o tribal, ningún procesador EBT o WIC, ningún comercio, Apple ni Google**.

La Aplicación no:

- se conecta a una cuenta EBT, PAN, NAP, WIC o gubernamental;
- carga, recibe, emite, transfiere ni procesa beneficios;
- muestra ni verifica balances o transacciones oficiales;
- decide elegibilidad de SNAP, PAN, NAP, WIC, hogares o artículos;
- envía compras de supermercado ni procesa pagos de supermercado o de beneficios; ni
- garantiza cómo una tienda, terminal, agencia o programa tratará un artículo o transacción.

Controlan las reglas oficiales, la cuenta oficial, los sistemas del comercio, los recibos y la ley. Confirma información importante con una fuente oficial.

## 6. Entradas, clasificaciones y balances registrados

Los resultados dependen de lo que escribes y escoges. **Balance registrado** significa solamente la cifra local. Registrar manualmente un cambio de balance o beneficio afecta solo esa cifra; no añade beneficios a una tarjeta real.

**Marcado como elegible**, **marcado como no elegible** y **no estoy seguro** son etiquetas personales. No son asesoría legal, decisión de una agencia ni garantía de un comercio. Una clasificación recordada para un artículo con el mismo nombre es solo una conveniencia; debes revisarla.

Las correcciones de precio, cantidad, compra, forma de pago o detalles de una transacción pueden ajustar el balance registrado. Una reclasificación histórica puede cambiar informes y selecciones futuras sin cambiar una cuenta real ni reescribir automáticamente un cargo histórico. Revisa todo antes de confiar.

## 7. Tus responsabilidades

Aceptas:

- ingresar información legalmente y revisarla;
- usar fuentes oficiales cuando necesites una cifra o decisión exacta;
- proteger el dispositivo;
- revisar precios y clasificaciones de carritos copiados;
- revisar informes antes de compartir; y
- borrar archivos exportados de todos los destinos donde ya no los quieras.

**Nunca escribas ni envíes un número de tarjeta EBT, Tarjeta de la Familia o WIC; PIN; número de Seguro Social; credencial gubernamental ni otro secreto de acceso.** La Aplicación no los necesita. El equipo de ayuda nunca pedirá tu PIN.

Conservas tus derechos sobre tus entradas. Como el Proveedor no recibe los registros locales, no le concedes licencia sobre ellos. Si envías información voluntariamente al equipo de ayuda, permites el uso limitado para responder, proteger la Aplicación y cumplir obligaciones según la Política de privacidad.

## 8. Anuncios

La Aplicación usa Google Mobile Ads y solicita anuncios no personalizados. Puede mostrar solamente un banner a la vez en un área separada de las pantallas compatibles. No usa anuncios intersticiales, recompensados, integrados ni nativos.

El banner no aparece en **Tarjetas y presupuestos** y se oculta temporalmente durante ventanas, teclado de cantidades, confirmación de compra, exportación o impresión. La publicidad nunca desbloquea, restringe ni retrasa funciones, informes o exportaciones. Si el consentimiento no permite solicitar anuncios, no hay anuncio disponible o el dispositivo está desconectado, la Aplicación sigue funcionando y ningún anuncio cubre controles de entrada o navegación.

La Aplicación no ofrece suscripciones, compras consumibles o no consumibles dentro de la aplicación ni acceso pagado sin anuncios. Google y las fuentes participantes controlan el contenido y la disponibilidad del banner. Usa **Configuración → Informar un anuncio** o el control del propio anuncio para informar publicidad inapropiada. Las opciones de privacidad aparecen en Configuración cuando se requieren. Consulta la [Política de privacidad](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) y el [Centro de ayuda](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html).

## 9. Almacenamiento, exportaciones y posible pérdida

Los registros están en el contenedor local privado. La copia de datos está desactivada en Android, y los archivos del registro en iOS se configuran para no incluirse en iCloud o nube del dispositivo. El almacenamiento transaccional y la recuperación local reducen riesgos, pero no garantizan recuperación después de desinstalación, borrado, pérdida, falla o acción del sistema.

Los informes CSV, XLSX compatibles con Excel y PDF se generan en el dispositivo y pueden contener información privada. Los informes exportados no son copias que la Aplicación pueda restaurar. La copia del Historial identificada por separado es un archivo JSON importable que contiene solamente el historial de transacciones; no contiene ni restaura los saldos actuales, beneficios WIC disponibles ni el presupuesto. Puede exportarse sin cifrar o cifrada con una frase de acceso. El Proveedor no recibe el archivo ni la frase y no puede recuperar una frase olvidada.

Cuando guardas o compartes un informe o copia del Historial, el destino controla esa copia. El Proveedor no puede recuperarla ni borrarla. Los archivos temporales creados por la Aplicación se eliminan después del intento de compartir o la próxima vez que se abre si se interrumpe la limpieza.

Usa **Configuración → Borrar todos los datos** para restablecer permanentemente tarjetas, balances, beneficios WIC, presupuestos, transacciones, correcciones, borradores, listas guardadas, registros y lotes importados, filtros, sugerencias, preferencias y recuperación local, y volver a la configuración inicial. Esto no borra archivos ya exportados o compartidos, consentimientos publicitarios de terceros ni información conservada independientemente por Apple, Google, correo o destinos de compartir.

## 10. No es asesoría profesional u oficial

La Aplicación es una ayuda manual para el hogar. No es asesoría financiera, legal, contributiva, nutricional, social, de beneficios ni profesional. Los informes se basan solamente en entradas guardadas y no son estados, recibos o decisiones oficiales.

Para balance, transacción, regla de alimentos, tarjeta perdida, fraude, compra denegada o decisión oficial, contacta la agencia, servicio de tarjeta, comercio o recurso de USDA aplicable.

## 11. Privacidad

La [Política de privacidad](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html) explica almacenamiento, Google Mobile Ads y UMP, comunicaciones con el equipo de ayuda, exportaciones, conservación, eliminación, uso adulto, procesamiento internacional y opciones. Al usar la Aplicación reconoces esas prácticas. Los consentimientos publicitarios se manejan mediante el proceso aplicable.

## 12. Servicios de terceros

La Aplicación depende en parte de software y servicios de Apple o Google, Google Mobile Ads y UMP, funciones del sistema, correo y destinos que eliges. Sus términos aplican. El Proveedor no controla disponibilidad, anuncios, sistemas oficiales, comercios ni destinos.

El Proveedor—no Apple, Google, USDA, ninguna agencia, ningún procesador ni ningún comercio—es responsable de la Aplicación y su Centro de ayuda, salvo donde los términos de una tienda dispongan otra cosa. Apple y Google no tienen obligación de mantenimiento ni soporte fuera de sus propias obligaciones.

Consulta [Avisos de terceros](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/third-party-notices.html).

## 13. Propiedad y marcas

El Proveedor y sus licenciantes poseen el software, diseño, texto, gráficos y material original, excepto tus entradas y material de terceros. Estos Términos no transfieren propiedad. El software de código abierto sigue sus licencias.

Los nombres y marcas de terceros, incluidos SNAP, EBT, PAN, NAP, USDA, Apple, Google y Excel, se mencionan únicamente con fines descriptivos y permanecen como propiedad de sus respectivos titulares, cuando corresponda. Su mención no implica respaldo.

## 14. Disponibilidad, actualizaciones y cambios

Buscamos mantener la Aplicación útil, segura y compatible, pero no prometemos disponibilidad continua, disponibilidad de anuncios, compatibilidad con todo dispositivo o destino, permanencia de funciones ni aceptación de todo archivo.

Podemos actualizar para corregir, mejorar seguridad o accesibilidad, mantener compatibilidad o responder a ley o tiendas. Apple y Google controlan aceptación y permanencia en sus tiendas.

## 15. Exclusión de garantías

Hasta donde la ley permita, la Aplicación se ofrece **“tal cual” y “según disponibilidad.”** El Proveedor excluye garantías implícitas de comerciabilidad, idoneidad, no infracción, exactitud y operación continua o sin errores.

Esto no excluye derechos o remedios que la ley del consumidor no permita excluir.

## 16. Límite de responsabilidad

Hasta donde la ley permita, el Proveedor no responde por daños indirectos, incidentales, especiales, consecuentes, ejemplares o punitivos, ni por pérdida de datos o beneficios, transacciones denegadas, demoras, vergüenza, pérdida del dispositivo u oportunidades, ni por confiar en entradas, clasificaciones, balances, informes, anuncios, decisiones de comercios, cambios de programas o servicios no disponibles.

Cuando la responsabilidad no pueda excluirse, se limita solo hasta donde la ley permita. Nada limita responsabilidad por fraude, conducta intencional, negligencia grave, lesión causada por negligencia o derechos que no puedan limitarse.

## 17. Fin del uso o distribución

Puedes dejar de usar en cualquier momento y usar **Configuración → Borrar todos los datos** antes de desinstalar. Podemos suspender el Centro de ayuda o la distribución por seguridad, abuso, ley, terceros o tiendas. Terminar la distribución no da acceso a los datos de tu dispositivo.

Las secciones que por su naturaleza deban continuar—propiedad, exclusiones, límites, ley y disputas—siguen vigentes.

## 18. Ley aplicable y disputas

Rigen las leyes de Ontario y las leyes federales aplicables de Canadá, sin reglas sobre conflicto de leyes. Esto **no** elimina protecciones obligatorias federales, estatales, territoriales o locales de una persona consumidora en Estados Unidos.

Antes de una reclamación, se recomienda intentar resolver escribiendo a `lrodeveloperr@gmail.com`. Este paso informal no acorta ningún plazo legal ni implica renunciar a él. Los tribunales de Ontario tienen jurisdicción no exclusiva, sujeto al derecho de acudir a otro foro competente bajo una disposición legal obligatoria.

No se exige arbitraje ni se renuncia a una acción colectiva cuando tal renuncia sea inválida o no esté disponible.

## 19. Términos generales

Si una disposición no puede exigirse, se limita o elimina solo lo mínimo, y las demás continúan. El hecho de no exigir el cumplimiento de una disposición no implica renunciar a ella. No puedes ceder sin consentimiento. El Proveedor puede ceder como parte de una transferencia legal de la Aplicación o actividad relacionada, sujeto a privacidad y protección del consumidor.

## 20. Cambios a estos Términos

Podemos actualizar por cambios en la Aplicación, anuncios, ley o tiendas. Se mostrará nueva fecha. Los cambios materiales se destacarán cuando sea razonablemente posible. Se pedirá aceptación nueva cuando la ley lo exija; de otro modo, continuar usando después de la fecha significa aceptación.

## 21. Contacto

**Proveedor:** Lateef Razaq-Oyetola  
**Ubicación:** Ontario, Canadá  
**Correo:** `lrodeveloperr@gmail.com`  
**Centro de ayuda:** [Centro de ayuda de SNAP-EBT & WIC Benefits Tracker](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html)
