---
title: Privacy Policy — SNAP-EBT & WIC Benefits Tracker
description: Privacy Policy for SNAP-EBT & WIC Benefits Tracker on Android and iOS
---

# SNAP-EBT & WIC Benefits Tracker Privacy Policy

**Effective date:** August 10, 2026  
**Last updated:** August 10, 2026  
**Applies to:** Version 1.0.0 on Android and iOS

SNAP-EBT & WIC Benefits Tracker (the **App**) is provided by **Lateef Razaq-Oyetola**, an individual developer in Ontario, Canada (**Publisher**, **we**, **us**, or **our**). The Google Play listing may display the developer-profile name **Good Use Studios**. That profile name is not a separate legal entity. The Apple App Store seller is **Lateef Razaq-Oyetola**.

The App is intended for adults in the 50 U.S. states, Washington, D.C., and Puerto Rico. It supports English and Puerto Rican Spanish. Program selection is separate from language selection: users may choose **SNAP/EBT — States and D.C.** or **Nutrition Assistance Program (NAP; PAN in Spanish) — Puerto Rico**.

This policy explains what remains on your device, what limited information may be processed off your device, and your choices. A substantively equivalent Puerto Rican Spanish version appears [below](#política-de-privacidad--español-puerto-rico).

## 1. Summary

- Grocery, SNAP/PAN, WIC, shopping-budget, tracked-balance, purchase, classification, and report information that you enter is kept in the App's private local storage. We do not automatically receive it and cannot retrieve it for you.
- The App has no account, login, Publisher-operated database, Publisher-operated cloud backup, subscription, or in-app purchase.
- The App uses **Google Mobile Ads (AdMob)**. The Mobile Ads and User Messaging Platform SDKs may process device, network, advertising-interaction, consent, and diagnostic information. We request non-personalized ads, but non-personalized ads are not data-free.
- We do not add your card names, balances, stores, grocery items, classifications, purchases, report filters, or report contents to an ad request.
- CSV, Excel-compatible XLSX, PDF, and History JSON files are created on your device. A destination you choose may copy, transmit, synchronize, or back up an exported file outside the App.
- If you email support, we receive your email address and anything you choose to include.

## 2. Information kept locally on your device

The App may keep the following in app-private local storage:

- locally named benefit-card records, card colors, and tracked balances;
- manually recorded benefit balances and changes;
- program and language choices;
- store names, draft carts, saved purchases, item names, prices, quantities, and dates;
- your own **marked eligible**, **marked not eligible**, and **not sure** classifications;
- corrections, deletions, copied carts, recent item names, and learned matching classifications;
- report filters and selections;
- local settings and draft-recovery information; and
- limited consent-interface and banner-presentation state needed to apply the App's advertising rules.

The App uses this information only for its on-device cards, budgets, logging, history, correction, classification, reporting, and recovery functions. We do not automatically receive, view, or synchronize the tracker information.

The App does not ask for or need an EBT, Family Card, or WIC card number; PIN; Social Security number; government-account credential; or official benefit-account login. **Do not enter those details in card names, store names, item names, support messages, screenshots, or exported files.**

### Local storage, recovery, and backups

The App stores tracker records in its private application container and uses transactional writes and local recovery data to reduce the risk of loss from an interrupted save. Recovery data contains the same type of tracker information and remains inside the App's private storage.

There is no Publisher cloud account or cloud backup. Android app-data backup is disabled. On iOS, App-created tracker files are configured not to be included in iCloud or device-cloud backup. These settings are intended to prevent ordinary cloud backup of tracker records, but an operating system, device manufacturer, or user-directed device migration may independently control some device-to-device transfers. We do not receive those transfers. Operating-system and store services may still process app installation, device, or diagnostic information under their own policies.

Local storage protects normal use without internet, but it cannot protect against uninstalling the App, clearing app storage, loss or failure of the device, or physical access to an unlocked device. An exported report is not a restorable App backup.

## 3. Information processed off your device

### A. Google Mobile Ads and privacy messaging

The App uses Google Mobile Ads for one banner at a time in a dedicated area on eligible screens. It does not use interstitial, rewarded, inline, or native ad formats. At each launch, and again when appropriate after the App resumes, it uses Google's User Messaging Platform (**UMP**) to refresh consent information and check whether a privacy message or privacy-options entry point is required before the banner is requested.

According to Google, the Mobile Ads SDK may automatically collect and share:

- the device's IP address, which may be used to estimate general location;
- app and ad interactions, such as app launches, taps, ad impressions, and video views;
- diagnostic and performance information, such as launch time, hang rate, crashes, and energy use; and
- device or account identifiers, such as the Android advertising ID, app-set ID, or other advertising and attribution identifiers when available.

Google and participating advertising partners may use this information for ad delivery, contextual selection, frequency capping, aggregated reporting, measurement, fraud prevention, security, and service operation. Google and its partners process information under their own terms and privacy policies and may process it in the United States or other countries.

We configure the App to:

- request **non-personalized ads**;
- complete any required UMP privacy flow before requesting or preloading ads;
- provide **Settings → Advertising privacy choices** when required;
- avoid requesting precise-location permission;
- avoid sending locally entered shopping information or report contents as ad-request data;
- avoid requesting Apple's App Tracking Transparency permission; and
- disable Google's publisher first-party identifier in the iOS version.

Non-personalized ads are not based on past behavior for targeting, but Google explains that cookies or mobile identifiers may still be used for frequency capping and aggregated ad reporting. On iOS, Google may also use Apple's privacy-preserving attribution systems, such as SKAdNetwork, without giving the App access to your identity.

We may receive aggregate or pseudonymous AdMob reports, including impressions, fill, estimated revenue, errors, and performance. Those reports do not give us your locally entered cards, balances, stores, items, purchases, or reports.

Google's current explanations are available at:

- [How Google uses information from sites or apps that use its services](https://policies.google.com/technologies/partner-sites)
- [Google Privacy Policy](https://policies.google.com/privacy)
- [Google Mobile Ads data disclosure for Android](https://developers.google.com/admob/android/privacy/play-data-disclosure)
- [Non-personalized ad serving](https://developers.google.com/admob/android/privacy/ad-serving-modes)

### B. Banner behavior

The App's core tracking and reports work without internet. The banner may appear only in a dedicated area on eligible screens. It is not displayed on **Cards & Budgets** and is temporarily hidden while a modal, money-entry keypad, checkout commit, report export, or print flow is active.

The banner never determines whether a feature, report, or export is available. If consent does not permit an ad request, no ad can load, or the device is offline, the App remains usable and no ad layer covers or disables an input or navigation control.

The App includes **Settings → Report an ad**. You may also use an ad's own information or reporting control where available. See the [Support page](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html) for the information that helps us investigate without exposing private shopping data.

### C. Support communications

If you email `lrodeveloperr@gmail.com`, we receive your email address and anything you voluntarily include, such as your name, message, app version, device model, operating-system version, screenshots, or attachments. We use that information to answer the request, troubleshoot, respond to privacy or ad concerns, protect the App and users, document the resolution, and meet legal obligations.

Support email is handled through Google's email service and may be processed outside Canada. Do not email card numbers, PINs, Social Security numbers, government credentials, or unredacted reports.

We do not use support messages for unrelated marketing. We normally delete or de-identify support correspondence within **24 months after the last substantive contact**, unless it is reasonably needed longer for security, fraud prevention, a legal obligation, or an active dispute.

### D. Apple, Google Play, operating-system services, and external links

The App does not offer subscriptions or in-app purchases and does not send purchase-entitlement information to the Publisher.

Apple or Google may also independently process download, installation, store, device, crash, performance, rating, and usage information under their own terms, privacy policies, and device settings. They may provide us with store reviews and aggregate or pseudonymous operational reports.

If you open a legal, support, or official-government link, your browser and the destination site process the request under their own privacy practices.

## 4. Reports, temporary files, and sharing

CSV, Excel-compatible XLSX, and PDF reports are generated on the device and are not restorable App backups. The separately labelled History backup is an importable JSON file containing transaction history only; it does not contain or restore current card balances, WIC availability, or the shopping budget. A History backup may be exported unencrypted or encrypted with a passphrase. The Publisher does not receive the file or passphrase and cannot recover a forgotten passphrase.

The App may create a temporary private file while preparing the system share sheet. Temporary App-created report and History files are deleted after the share attempt finishes. If immediate cleanup is interrupted, stale temporary share files are deleted on the next App launch.

If you save or share a report, the destination you select—such as Files, email, messaging, cloud storage, or another app—may copy, transmit, synchronize, back up, or disclose it. We do not automatically receive the report and cannot delete exported copies for you. Delete an exported file separately from every destination where it was saved, shared, or backed up.

## 5. Permissions and features not used

The App uses internet and network-state access for ads and external links. It does not request access to your camera, microphone, contacts, calendar, precise GPS location, photos or media library, Bluetooth, NFC, biometrics, phone calls, or notifications. It does not process grocery or benefit payments or connect to an official benefit account.

## 6. Retention and deletion

- **App-local data and recovery data:** remain in private local storage until you edit a record, use **Settings → Clear All Data**, clear app storage, or uninstall the App. Clear All Data permanently resets local cards, balances, WIC benefits, shopping budgets, transactions, corrections, drafts, saved baskets, imported-history records and batches, report selections, learned suggestions, settings, and local recovery data, then returns to onboarding. It does not remove third-party ad-consent records, exported files, or information held by Apple, Google, an email provider, or a sharing destination. Clearing the App's storage through the operating system or uninstalling removes App-local data, subject to platform behavior.
- **Temporary App-created report and History files:** are deleted after the share attempt finishes. If immediate cleanup is interrupted, they are deleted on the next App launch. A copy saved or shared elsewhere must be deleted at that destination.
- **Advertising data and consent records:** are retained by Google and participating partners under their policies and settings. Use **Advertising privacy choices**, relevant device controls, or Google controls where available.
- **Support communications:** follow the retention period in Section 3C.
- **Aggregate store, advertising, and security records:** may be retained as reasonably necessary for accounting, fraud prevention, security, legal compliance, and dispute resolution.

Because we cannot access your locally stored tracker data, we cannot view, export, correct, or remotely delete it.

## 7. Your choices and privacy rights

Your direct controls include:

- correcting local transactions, deleting saved baskets, and deleting imported History records;
- using **Settings → Clear All Data**;
- using **Settings → Advertising privacy choices** when displayed;
- using **Settings → Report an ad** for inappropriate or age-inappropriate ads;
- managing advertising settings through your device or Google; and
- deleting exported files from their destinations.

Depending on applicable law, you may have rights to request access to, correction of, or deletion of Publisher-controlled personal information, to withdraw consent, or to ask about disclosures. Email `lrodeveloperr@gmail.com` with **Privacy Request** in the subject line. We may ask for information reasonably necessary to verify and fulfill the request. We will not discriminate against you for exercising an applicable privacy right.

If applicable law treats advertising disclosures as a sale, sharing, or targeted advertising, use the available advertising privacy control or contact us. We do not sell your locally entered tracker data or support communications for money.

The App is not a browser and does not respond to browser Do Not Track signals. We do not use locally entered shopping data to build a profile of your activity across other companies' apps or websites. Google and advertising partners may process information across services as described in their policies and your privacy choices.

## 8. Adults only

The App is intended only for adults aged **18 or older** and is not directed to children. We do not knowingly ask a child to provide personal information. The App must not be listed in a children-focused or Google Play Families category. If you believe a child sent personal information to support, contact us so we can take appropriate action.

## 9. Security

We use reasonable administrative and technical measures appropriate to the limited information we control. Local tracker data is kept in the App's private container, and information transmitted to Google Mobile Ads or email services is protected in transit by those services. No device, SDK, email service, transmission, or storage method is completely secure.

Protect your device with a passcode, keep its operating system updated, review reports before sharing, and never store authentication secrets in the App. If a breach involving Publisher-controlled personal information requires notice, we will follow applicable notification and record-keeping requirements.

## 10. International processing

We operate from Ontario, Canada, and offer the App to adults in the United States and Puerto Rico. Support, advertising, and store-platform information may be processed in Canada, the United States, or other countries where service providers operate. Information processed in another country may be subject to that country's lawful-access rules.

Service providers acting on our behalf are required to protect Publisher-controlled personal information consistently with this policy and applicable law. We require each third party with whom the App shares user data, including advertising networks and SDK providers, to provide the same or equal protection described in this policy and required by applicable store rules. Apple, Google, advertising partners, email providers, and user-selected sharing destinations may also act independently under their own published terms and privacy policies.

## 11. Changes to this policy

We may update this policy to reflect changes in the App, service providers, law, or store requirements. The updated page will show a new effective date. Material changes will also be highlighted in the App, release notes, or store listing when reasonably practicable, and renewed consent will be requested when required by law.

## 12. Contact and complaints

**Privacy Lead:** Lateef Razaq-Oyetola  
**Mailing address:** 36 Zorra Street, Toronto, Ontario M8Z 0G5, Canada  
**Email:** `lrodeveloperr@gmail.com`  
**Support:** [SNAP-EBT & WIC Benefits Tracker Support](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html)

You may also contact the [Office of the Privacy Commissioner of Canada](https://www.priv.gc.ca/en/report-a-concern/) or the privacy or consumer-protection authority with jurisdiction where you live.

## 13. Independent-app notice

SNAP, EBT, PAN, NAP, and WIC are used descriptively. The App is **not affiliated with, endorsed by, authorized by, sponsored by, or operated by the U.S. Department of Agriculture (USDA), the USDA Food and Nutrition Administration (FNA, formerly FNS), the Puerto Rico Department of the Family or ADSEF, any state, territorial, or tribal agency, any EBT or WIC processor, any retailer, Apple, or Google**.

The App does not connect to a benefit account, add or transfer benefits, display an official balance, determine official item or program eligibility, or process grocery or benefit payments.

---

# Política de privacidad — Español (Puerto Rico)

**Fecha de vigencia:** 10 de agosto de 2026  
**Última actualización:** 10 de agosto de 2026  
**Aplica a:** Versión 1.0.0 en Android y iOS

SNAP-EBT & WIC Benefits Tracker (la **Aplicación**) es ofrecida por **Lateef Razaq-Oyetola**, desarrollador individual en Ontario, Canadá (el **Proveedor**, **nosotros** o **nuestro**). La ficha de Google Play puede mostrar el nombre de perfil de desarrollador **Good Use Studios**. Ese nombre de perfil no es una entidad legal separada. El vendedor en Apple App Store es **Lateef Razaq-Oyetola**.

La Aplicación está destinada a personas adultas en los 50 estados de Estados Unidos, Washington D.C. y Puerto Rico. Incluye inglés y español de Puerto Rico. La selección del programa es independiente del idioma: se puede escoger **SNAP/EBT — Estados y D.C.** o **Programa de Asistencia Nutricional (PAN; NAP, por sus siglas en inglés) — Puerto Rico**.

Esta política explica qué permanece en tu dispositivo, qué información limitada puede procesarse fuera del dispositivo y cuáles son tus opciones.

## 1. Resumen

- La información de supermercado, SNAP/PAN, WIC, presupuesto de compra, balance registrado, compras, clasificaciones e informes que escribes se guarda en el almacenamiento local privado de la Aplicación. No la recibimos automáticamente ni podemos recuperarla por ti.
- No hay cuenta, inicio de sesión, base de datos operada por el Proveedor, copia en la nube operada por el Proveedor, suscripción ni compra dentro de la Aplicación.
- La Aplicación usa **Google Mobile Ads (AdMob)**. Los SDK de anuncios y User Messaging Platform pueden procesar información del dispositivo, red, interacción publicitaria, consentimiento y diagnóstico. Solicitamos anuncios no personalizados, pero eso no significa que no se procesen datos.
- No añadimos nombres de tarjetas, balances, tiendas, artículos, clasificaciones, compras, filtros ni contenido de informes a una solicitud de anuncios.
- Los archivos CSV, XLSX compatibles con Excel, PDF y JSON del Historial se crean en el dispositivo. Un destino que elijas puede copiar, transmitir, sincronizar o guardar un archivo exportado fuera de la Aplicación.
- Si escribes al equipo de ayuda, recibimos tu dirección de correo y lo que decidas incluir.

## 2. Información que permanece en el dispositivo

La Aplicación puede guardar en almacenamiento local privado:

- registros locales de tarjetas, colores y balances registrados;
- balances de beneficios y cambios registrados manualmente;
- selecciones de programa e idioma;
- nombres de tiendas, carritos en curso, compras, artículos, precios, cantidades y fechas;
- tus clasificaciones de **marcado como elegible**, **marcado como no elegible** y **no estoy seguro**;
- correcciones, eliminaciones, carritos copiados, artículos recientes y clasificaciones recordadas;
- filtros y selecciones de informes;
- preferencias locales e información de recuperación de borradores; y
- estado limitado de la interfaz de consentimiento y presentación del banner necesario para aplicar las reglas publicitarias.

La Aplicación usa esta información solamente para las funciones locales de tarjetas, presupuestos, registro, historial, corrección, clasificación, informes y recuperación. No recibimos, vemos ni sincronizamos automáticamente la información del registro.

La Aplicación no pide ni necesita un número de tarjeta EBT, Tarjeta de la Familia o WIC; PIN; número de Seguro Social; credencial gubernamental ni acceso oficial a una cuenta de beneficios. **No escribas esos datos en nombres de tarjetas, tiendas o artículos, mensajes al equipo de ayuda, capturas ni archivos exportados.**

### Almacenamiento, recuperación y copias

La Aplicación guarda los registros dentro de su contenedor privado y usa escrituras transaccionales y datos locales de recuperación para reducir el riesgo de pérdida por una interrupción. Esos datos contienen el mismo tipo de información y permanecen en el almacenamiento privado.

No existe una cuenta o copia en la nube del Proveedor. La copia de datos de la Aplicación está desactivada en Android. En iOS, los archivos del registro se configuran para no incluirse en copias de iCloud o de la nube del dispositivo. Estos ajustes buscan impedir copias ordinarias en la nube, pero el sistema, fabricante o una migración iniciada por la persona puede controlar independientemente ciertas transferencias entre dispositivos. No recibimos esas transferencias. Los servicios del sistema y de la tienda todavía pueden procesar información de instalación, dispositivo o diagnóstico bajo sus propias políticas.

El almacenamiento local permite el uso normal sin internet, pero no protege contra desinstalación, borrado del almacenamiento, pérdida o falla del dispositivo ni acceso físico a un dispositivo desbloqueado. Un informe exportado no es una copia que la Aplicación pueda restaurar.

## 3. Información procesada fuera del dispositivo

### A. Google Mobile Ads y mensajes de privacidad

La Aplicación usa Google Mobile Ads para mostrar un solo banner a la vez en un área separada de las pantallas compatibles. No usa anuncios intersticiales, recompensados, integrados ni nativos. En cada inicio, y nuevamente cuando corresponde al volver a primer plano, usa User Messaging Platform (**UMP**) para actualizar la información de consentimiento y verificar si se requiere un mensaje de privacidad o acceso a opciones antes de solicitar el banner.

Según Google, el SDK puede recopilar y compartir automáticamente:

- dirección IP, que puede usarse para estimar una ubicación general;
- interacciones con la Aplicación y los anuncios, como aperturas, toques, impresiones y vistas de video;
- información de diagnóstico y rendimiento, como tiempo de inicio, bloqueos, fallas y uso de energía; e
- identificadores del dispositivo o cuenta, como el identificador publicitario de Android, App Set ID u otros identificadores publicitarios y de atribución disponibles.

Google y los socios publicitarios pueden usarla para entregar y seleccionar anuncios contextuales, limitar frecuencia, producir informes agregados, medir, prevenir fraude, mantener seguridad y operar el servicio. Pueden procesarla en Estados Unidos u otros países bajo sus propios términos y políticas.

Configuramos la Aplicación para:

- solicitar **anuncios no personalizados**;
- completar cualquier proceso UMP requerido antes de solicitar o precargar anuncios;
- mostrar **Configuración → Opciones de privacidad de anuncios** cuando corresponda;
- no pedir ubicación precisa;
- no enviar información local de compras o contenido de informes en solicitudes publicitarias;
- no solicitar permiso de App Tracking Transparency de Apple; y
- desactivar el identificador propio del editor de Google en iOS.

Los anuncios no personalizados no usan comportamiento anterior para seleccionar anuncios, pero Google explica que identificadores móviles todavía pueden usarse para limitar frecuencia e informes agregados. En iOS, Google también puede usar sistemas de atribución de Apple que preservan privacidad, como SKAdNetwork, sin revelar tu identidad a la Aplicación.

Podemos recibir informes agregados o seudonimizados de AdMob sobre impresiones, disponibilidad, ingresos estimados, errores y rendimiento. No muestran tus tarjetas, balances, tiendas, artículos, compras ni informes locales.

Consulta:

- [Cómo usa Google la información de sitios o aplicaciones que utilizan sus servicios](https://policies.google.com/technologies/partner-sites?hl=es)
- [Política de Privacidad de Google](https://policies.google.com/privacy?hl=es)
- [Divulgación de datos de Google Mobile Ads para Android](https://developers.google.com/admob/android/privacy/play-data-disclosure)
- [Anuncios no personalizados](https://developers.google.com/admob/android/privacy/ad-serving-modes)

### B. Comportamiento del banner

Las funciones principales y los informes trabajan sin internet. El banner solo puede aparecer en un área separada de las pantallas compatibles. No aparece en **Tarjetas y presupuestos** y se oculta temporalmente durante ventanas, teclado de cantidades, confirmación de compra, exportación o impresión.

El banner nunca determina si una función, informe o exportación está disponible. Si el consentimiento no permite solicitar anuncios, no carga un anuncio o el dispositivo está desconectado, la Aplicación sigue funcionando y ningún anuncio cubre ni desactiva controles de entrada o navegación.

La Aplicación incluye **Configuración → Informar un anuncio**. También puedes usar el control del propio anuncio cuando esté disponible. Consulta el [Centro de ayuda](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html) para informar sin revelar datos privados de compras.

### C. Comunicaciones con el equipo de ayuda

Si escribes a `lrodeveloperr@gmail.com`, recibimos tu dirección y lo que incluyas, como nombre, mensaje, versión, modelo del dispositivo, versión del sistema, capturas o archivos. Lo usamos para responder, investigar problemas, atender privacidad o anuncios, proteger la Aplicación, documentar la solución y cumplir obligaciones legales.

El correo se maneja mediante el servicio de Google y puede procesarse fuera de Canadá. No envíes números de tarjeta, PIN, Seguro Social, credenciales gubernamentales ni informes sin ocultar datos.

No usamos mensajes al equipo de ayuda para mercadeo no relacionado. Normalmente los eliminamos o desidentificamos **dentro de los 24 meses siguientes al último contacto sustantivo**, salvo que sea razonablemente necesario conservarlos por seguridad, prevención de fraude, obligación legal o disputa activa.

### D. Apple, Google Play, sistema operativo y enlaces

La Aplicación no ofrece suscripciones ni compras dentro de la aplicación y no envía información sobre derechos de compra al Proveedor.

Apple o Google también pueden procesar de forma independiente información de descarga, instalación, tienda, dispositivo, fallas, rendimiento, calificaciones y uso bajo sus políticas y ajustes. Pueden darnos reseñas e informes operativos agregados o seudonimizados.

Si abres un enlace legal, del Centro de ayuda o gubernamental, el navegador y el destino procesan la solicitud bajo sus propias prácticas.

## 4. Informes, archivos temporales y compartir

Los informes CSV, XLSX compatibles con Excel y PDF se generan en el dispositivo y no son copias que la Aplicación pueda restaurar. La copia del Historial identificada por separado es un archivo JSON importable que contiene solamente el historial de transacciones; no contiene ni restaura los saldos actuales, beneficios WIC disponibles ni el presupuesto de compra. Puede exportarse sin cifrar o cifrada con una frase de acceso. El Proveedor no recibe el archivo ni la frase y no puede recuperar una frase olvidada.

La Aplicación puede crear un archivo temporal privado mientras prepara la hoja del sistema para compartir. Los archivos temporales de informes y del Historial creados por la Aplicación se eliminan después de terminar el intento de compartir. Si se interrumpe la limpieza inmediata, los archivos temporales pendientes se eliminan la próxima vez que se abre la Aplicación.

Si guardas o compartes, el destino—por ejemplo, Archivos, correo, mensajería, nube u otra aplicación—puede copiar, transmitir, sincronizar, respaldar o divulgar el archivo. No lo recibimos automáticamente ni podemos borrar copias por ti. Elimina cada copia desde el destino donde fue guardada, compartida o respaldada.

## 5. Permisos y funciones que no se usan

La Aplicación usa internet y estado de red para anuncios y enlaces externos. No pide cámara, micrófono, contactos, calendario, GPS preciso, fotos o biblioteca de medios, Bluetooth, NFC, biometría, llamadas ni notificaciones. No procesa compras de supermercado ni pagos de beneficios, ni se conecta a una cuenta oficial de beneficios.

## 6. Conservación y eliminación

- **Datos locales y de recuperación:** permanecen en almacenamiento privado hasta que corrijas un registro, uses **Configuración → Borrar todos los datos**, borres el almacenamiento o desinstales. Borrar todos los datos restablece permanentemente tarjetas, balances, beneficios WIC, presupuestos, transacciones, correcciones, borradores, listas guardadas, registros y lotes importados, filtros, sugerencias, preferencias y recuperación local, y vuelve a la configuración inicial. No borra consentimientos publicitarios de terceros, archivos exportados ni información de Apple, Google, correo o destinos de compartir. Borrar el almacenamiento mediante el sistema o desinstalar elimina los datos locales, sujeto al comportamiento de la plataforma.
- **Archivos temporales de informes y del Historial:** se eliminan después de terminar el intento de compartir. Si se interrumpe la limpieza inmediata, se eliminan la próxima vez que se abre la Aplicación. Una copia guardada o compartida se elimina en su destino.
- **Datos y consentimientos publicitarios:** Google y sus socios los conservan según sus políticas. Usa **Opciones de privacidad de anuncios**, controles del dispositivo o controles de Google.
- **Mensajes al equipo de ayuda:** siguen el período de la Sección 3C.
- **Registros agregados de tienda, anuncios y seguridad:** pueden conservarse cuando sea razonablemente necesario para contabilidad, fraude, seguridad, ley y disputas.

Como no podemos acceder a tus datos locales, no podemos verlos, exportarlos, corregirlos ni borrarlos remotamente.

## 7. Opciones y derechos

Puedes:

- corregir transacciones locales, borrar listas guardadas y eliminar registros importados del Historial;
- usar **Configuración → Borrar todos los datos**;
- usar **Configuración → Opciones de privacidad de anuncios** cuando aparezca;
- usar **Configuración → Informar un anuncio**;
- administrar publicidad en el dispositivo o Google; y
- borrar archivos exportados de sus destinos.

Según la ley aplicable, puedes pedir acceso, corrección o eliminación de información controlada por el Proveedor, retirar consentimiento o preguntar por divulgaciones. Escribe a `lrodeveloperr@gmail.com` con **Solicitud de privacidad** en el asunto. Podemos pedir información razonablemente necesaria para verificar y atender la solicitud. No te discriminaremos por ejercer un derecho aplicable.

Si una ley trata divulgaciones publicitarias como venta, intercambio o publicidad dirigida, usa el control de privacidad disponible o contáctanos. No vendemos por dinero tus datos locales ni mensajes al equipo de ayuda.

La Aplicación no es un navegador y no responde a señales Do Not Track. No usamos datos locales para crear un perfil de tu actividad en aplicaciones o sitios de otras compañías. Google y socios pueden procesar información entre servicios según sus políticas y tus elecciones.

## 8. Solo para personas adultas

La Aplicación está destinada solamente a personas de **18 años o más** y no está dirigida a menores. No pedimos conscientemente información personal a un menor. No debe aparecer en categorías para niños o Familias de Google Play. Si crees que un menor envió información al equipo de ayuda, contáctanos.

## 9. Seguridad

Usamos medidas administrativas y técnicas razonables para la información limitada que controlamos. Los datos locales están en el contenedor privado, y los servicios de Google Mobile Ads o correo protegen en tránsito la información que reciben. Ningún dispositivo, SDK, correo, transmisión o almacenamiento es completamente seguro.

Protege el dispositivo con código, actualiza el sistema, revisa informes antes de compartir y nunca guardes secretos de acceso en la Aplicación. Si un incidente o violación de seguridad que afecte información personal controlada por el Proveedor exige aviso, cumpliremos las obligaciones aplicables.

## 10. Procesamiento internacional

Operamos desde Ontario, Canadá, y ofrecemos la Aplicación a personas adultas en Estados Unidos y Puerto Rico. La información relacionada con el Centro de ayuda, la publicidad y las plataformas de distribución puede procesarse en Canadá, Estados Unidos u otros países donde operan proveedores. Puede quedar sujeta a las reglas de acceso legal de esos países. Los datos del registro de supermercado permanecen en el dispositivo salvo que tú exportes y compartas un archivo.

Los proveedores que actúan por cuenta nuestra deben proteger la información controlada por el Proveedor de forma consistente con esta política y la ley aplicable. Exigimos que cada tercero con quien la Aplicación comparta datos de usuarios, incluidas las redes publicitarias y los proveedores de SDK, brinde la misma protección o una protección equivalente a la descrita en esta política y exigida por las reglas aplicables de las tiendas. Apple, Google, socios publicitarios, proveedores de correo y destinos elegidos también pueden actuar independientemente bajo sus términos y políticas publicados.

## 11. Cambios

Podemos actualizar esta política por cambios en la Aplicación, proveedores, ley o tiendas. La página mostrará una nueva fecha. Los cambios materiales también se destacarán en la Aplicación, notas o ficha cuando sea razonablemente posible, y se pedirá consentimiento nuevo cuando la ley lo exija.

## 12. Contacto y quejas

**Responsable de privacidad:** Lateef Razaq-Oyetola  
**Dirección postal:** 36 Zorra Street, Toronto, Ontario M8Z 0G5, Canadá  
**Correo:** `lrodeveloperr@gmail.com`  
**Centro de ayuda:** [Centro de ayuda de SNAP-EBT & WIC Benefits Tracker](https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/support.html)

También puedes contactar a la [Oficina del Comisionado de Privacidad de Canadá](https://www.priv.gc.ca/en/report-a-concern/) o a la autoridad de privacidad o protección del consumidor que corresponda.

## 13. Aviso de aplicación independiente

SNAP, EBT, PAN, NAP y WIC se mencionan únicamente con fines descriptivos. La Aplicación **no está afiliada, respaldada, autorizada, patrocinada ni operada por USDA, la Food and Nutrition Administration (FNA, antes FNS), el Departamento de la Familia de Puerto Rico o ADSEF, ninguna agencia estatal, territorial o tribal, ningún procesador EBT o WIC, ningún comercio, Apple ni Google**.

La Aplicación no se conecta a una cuenta, añade o transfiere beneficios, muestra un balance oficial, determina elegibilidad oficial de artículos o programas ni procesa compras de supermercado o pagos de beneficios.
