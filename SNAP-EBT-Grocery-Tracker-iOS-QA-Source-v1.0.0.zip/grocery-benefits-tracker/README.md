# SNAP-EBT & WIC Benefits Tracker

This archive contains the same React Native wrapper and local-first web application used by the reviewed iOS release workflow. It is not a second or legacy implementation.

## Current product

- Manually tracks locally named SNAP/PAN cards, WIC benefits, a cash shopping budget, baskets, and transaction history.
- Keeps tracker data in app-private local storage. There is no App account or Publisher cloud database.
- Creates CSV, XLSX, and PDF reports and encrypted or unencrypted History-only JSON backups on the device.
- Uses one Google Mobile Ads banner on eligible screens. Requests are non-personalized; Cards & Budgets and modal/checkout/export flows have no banner.
- Has no subscription, in-app purchase, rewarded ad, interstitial ad, inline ad, or native ad.
- Does not use application-triggered vibration or haptic feedback.

The tracker is independent and is not an official government, EBT, WIC, retailer, payment, or eligibility application.

## Reproducible validation

```sh
npm ci --no-audit --no-fund
npm run validate
```

`npm run validate` regenerates `src/appHtml.ts` from the hash-pinned `app.html`, runs TypeScript, and executes the adversarial release verifier. Native iOS validation additionally uses the reviewed GitHub Actions workflow, its locked CocoaPods graph, an unsigned device archive, and an iOS Simulator build.

## Advertising profiles

`EXPO_PUBLIC_AD_PROFILE=test` uses Google's official demo application and banner IDs. This is the only profile for physical QA builds. Never click live ads while testing.

`EXPO_PUBLIC_AD_PROFILE=production` fails closed unless all four public variables are present and none contains Google's demo publisher ID:

- `EXPO_PUBLIC_ANDROID_ADMOB_APP_ID`
- `EXPO_PUBLIC_ANDROID_ADMOB_BANNER_ID`
- `EXPO_PUBLIC_IOS_ADMOB_APP_ID`
- `EXPO_PUBLIC_IOS_ADMOB_BANNER_ID`

Test and production are separate builds with distinct build numbers. The internal iOS test-ad workflow permanently marks its upload as internal-TestFlight-only.

## Platform notes

- iOS release identity is injected and verified by the protected GitHub workflow before signing and upload.
- Android test builds use the `.qa` application-id suffix. A production Play build must use the final Play Console package identity and production AdMob variables.
- The 1024-pixel App icon, iOS splash assets, Android adaptive icon layers, in-app mark, and PDF mark derive from one reviewed logo source and are checksum-gated.

Legal and store-listing drafts are in `PRIVACY.md`, `TERMS.md`, `APP_STORE_LISTING.md`, and `STORE_LISTING.md`. The public URLs must be deployed and checked separately before App Review.
