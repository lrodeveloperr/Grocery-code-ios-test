# Apple App Store Listing — United States and Puerto Rico

**App:** SNAP-EBT & WIC Benefits Tracker  
**Seller:** Lateef Razaq-Oyetola  
**Category:** Shopping  
**Subtitle:** Plan groceries before checkout

## Promotional text

Plan privately, track the balance you recorded, and avoid surprise shortfalls or awkward split payments at checkout.

## Description

SNAP-EBT & WIC Benefits Tracker is a private, local-first companion for manually planning grocery purchases before checkout.

Choose SNAP/EBT for the states and Washington, D.C., or Puerto Rico's Nutrition Assistance Program (NAP; PAN in Spanish). Track locally named SNAP/PAN and WIC card records and a cash shopping budget without entering card numbers or PINs. Record the balances and benefits you checked, build carts with quantities and known or not-yet-known prices, reuse saved baskets, and choose your own eligible / not eligible / not sure classification for each item.

Search purchases and items, correct locally recorded transactions, delete imported History records, and clear all app-local data from Settings. Use filterable Overview, Benefits, Spending, and Trends reports, then share CSV, Excel-compatible XLSX, and U.S.-Letter PDF files generated on the device. You can also export or import an encrypted or unencrypted History-only backup.

Tracker data remains in app-private local storage. Core tracking and reports work without internet. There is no App account, Publisher database, or Publisher cloud backup.

The App is free and may show one non-personalized AdMob banner in a dedicated area on eligible screens. It has no subscriptions, in-app purchases, interstitial ads, rewarded ads, or inline/native ads. The banner is not shown on Cards & Budgets and never unlocks or blocks reports or exports.

SNAP-EBT & WIC Benefits Tracker is independent. It is not affiliated with, endorsed by, authorized by, sponsored by, or operated by USDA, FNA, the Puerto Rico Department of the Family or ADSEF, any government agency, EBT or WIC processor, or retailer. It does not connect to a benefit account, add or transfer benefits, display an official balance, determine official eligibility, or process grocery or benefit payments. Official program and retailer records control.

Never enter an EBT, Family Card, or WIC card number; PIN; Social Security number; or government-account credential.

Support: lrodeveloperr@gmail.com  
Privacy: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/privacy.html  
Terms: https://lrodeveloperr.github.io/SNAP-EBT-Grocery-Tracker/terms.html

## Keywords

grocery,SNAP,EBT,benefits,balance,cart,budget,shopping,report,tracker

## Puerto Rican Spanish localization

**Subtitle:** Planifica antes de pagar

Planifica en privado, registra los balances que consultaste y evita sorpresas al pagar. Escoge SNAP/EBT o el Programa de Asistencia Nutricional (PAN), registra tarjetas locales de PAN y WIC y un presupuesto de compra sin escribir números de tarjeta ni PIN, guarda carritos y compras, y usa tus propias clasificaciones.

Busca compras y artículos, corrige transacciones registradas, elimina registros importados del Historial y borra todos los datos locales desde Configuración. Consulta reportes filtrables de Resumen, Beneficios, Gastos y Tendencias y comparte archivos CSV, XLSX compatibles con Excel y PDF tamaño Carta generados en el dispositivo. También puedes exportar o importar una copia del Historial cifrada o sin cifrar.

La Aplicación es gratis y puede mostrar un solo banner no personalizado de AdMob en un área separada de las pantallas compatibles. No ofrece suscripciones ni compras dentro de la aplicación y no usa anuncios intersticiales, recompensados, integrados ni nativos. El banner no aparece en Tarjetas y presupuestos ni condiciona informes o exportaciones.

La Aplicación es independiente y no se conecta a ninguna cuenta ni agencia gubernamental.
