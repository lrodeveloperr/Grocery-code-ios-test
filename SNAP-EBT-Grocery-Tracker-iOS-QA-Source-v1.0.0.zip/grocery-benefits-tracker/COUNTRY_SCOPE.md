# Country Scope — Version 1.0.0

## Consumer market

Version 1.0.0 is intended for adults aged 18 or older in the 50 U.S. states, Washington, D.C., and Puerto Rico. Currency, dates, program wording, store metadata, non-government-affiliation disclosures, and Puerto Rican Spanish are U.S.-market specific.

The App provides separate manual modes:

- **SNAP/EBT — States and D.C.**
- **Nutrition Assistance Program (NAP; Programa de Asistencia Nutricional or PAN in Spanish) — Puerto Rico**, using Tarjeta de la Familia wording.

Program selection changes labels only. The App never connects to an official program, benefit account, card, agency, processor, or retailer.

## Canadian publisher

Lateef Razaq-Oyetola operates from Ontario, Canada, but Canada is not a consumer target market for version 1.0.0. Canadian privacy, consumer, advertising, tax, and business obligations that apply to the Publisher remain relevant.

A future Canadian consumer version would require separate benefit-program positioning and a new legal/store review.
